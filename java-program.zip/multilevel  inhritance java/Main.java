class kgf1
{
    void rocky1()
    {
        System.out.println("Powerful people come from powerful places ");
    }
}
class Kgf2 extends kgf1
{
    void adheera()
    {
        System.out.println("History Tells Us That Powerful People Come From Powerful Places.History Was Wrong");
        System.out.println("Powerful People Make Places Powerful");
    }
    void rocky()
    {
        System.out.println("Violence, Violence, Violence, I don’t like, 1 Avoid.… but Violence likes me, I can’t Avoid.");
    }
}

public class Main extends Kgf2
{
	public static void main(String[] args) {
	    Main prasanth_neel=new Main();
	    prasanth_neel.rocky1();
	    prasanth_neel.adheera();
	    prasanth_neel.rocky();
		System.out.println("KGF 3...2024");
	}
}
