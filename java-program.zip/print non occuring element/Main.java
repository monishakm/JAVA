import java.util.*;
public class Main 
    {
       public static void main (String args[]) 
       {
           Scanner sc = new Scanner(System.in);
           int n=sc.nextInt();
           int k=sc.nextInt();
           int a=0,rev=0;
           while(n!=0)
           {
               int r=n%10;
               if(r!=k)
               {
                   a=a*10+r;
               }
               n/=10;
               
           }
           while(a!=0)
           {
               int rem=a%10;
               rev=rev*10+rem;
               a/=10;
           }
           System.out.println(rev);
             
           
           
       }
    }
