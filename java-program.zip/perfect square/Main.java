import java.util.*;
public class Main
{
    public static void main (String args[])
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int k=sc.nextInt();
        for (int i=n;i<=k;i++)
        {
            for(int j=1;j<=k;j++)
            {
                if(j*j>=n && j*j<=k)
                System.out.println(j*j);
            }
            break;
        }
    }
}
