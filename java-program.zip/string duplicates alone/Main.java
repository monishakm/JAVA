import java.util.*;
public class Main
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        String str=sc.next();
        int count;
        char ch[]=str.toCharArray();
        for(int i=0;i<str.length();i++)
        {  
            count=1;
            for(int j=1+i;j<ch.length;j++)
            { 
                
                if(ch[i]==ch[j]){
                count+=1;
                   
                }
            }
            if(count>1)
            {
                System.out.print(ch[i]);
            }
        }
    }
}

