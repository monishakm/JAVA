import java.util.*;
public class Main
{
    public static void main(String args[])
    { 
        StringBuffer sc =new StringBuffer("TEAM");
        sc.append("TERV");
        System.out.println(sc);
    }
}
