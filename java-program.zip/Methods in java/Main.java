import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    double a=123.678;
	    String b=String.valueOf(a);
		System.out.println(b.indexOf('2'));
		b=b.replace('3','7');
		System.out.println(b);
		b=b.replaceFirst("7","9");
		System.out.println(b);
		String k="Team Terv";
		String j[]=k.split(" ",2);
		for(String i:j)
		System.out.println(i);
		String m[]=k.split("e");
			for(String i:m)
		System.out.println(i);
		k="hii terv team";
	   System.out.println(k.subSequence(4,8));
	   char v[]=k.toCharArray();
	   String x="";
	   x=x.copyValueOf(v,0,5);
	   System.out.println(x);
	}
}
