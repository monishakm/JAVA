
public class Main
{
	public static void main(String[] args) {
		int a=13,b=7;
		int c=a++;
		System.out.println(c);
		a=a^b;
		System.oout.println(a);
		c=c^b&&a^b;
		System.out.println(c<<3);
		System.out.println(c>b&&a<b);
		int d=a/c*b;
		System.out.println(d);
		b=d%c;
		int e=(b&a)^(d|c);
		System.out.println(e);
		System.out.println(e>c?b++:--a);
		System.out.println(e+d+d+c+b);
		d=a>>3;
	}
}
