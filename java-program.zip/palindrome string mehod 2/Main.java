import java.util.*;
public class Main 
{
    public static void main (String args[])
    {
        Scanner sc=new Scanner(System.in);
        String a=sc.next();
        int n=a.length();
        int c=0;
        for(int i=0,j=n-1;i<n/2;i++,j--)
        {
            if(a.charAt(i)!=a.charAt(j))
            c++;
        }
        System.out.println(c==0?"yes":"no");
    }
}