import java.util.*;
public class Main
{
    public static void main (String[] args) 
    {
       
           Scanner sc=new Scanner(System.in);
           int a=sc.nextInt();
           int b=sc.nextInt();
           int c=sc.nextInt();
           float d=sc.nextFloat();
           System.out.println("Outputs are:");
           System.out.println(Math.pow(a,b));
           System.out.println(Math.sqrt(c));
           System.out.println(Math.max(a,b));
           System.out.println(Math.min(a,c));
           System.out.println(Math.abs(a-b));
           System.out.println(Math.pow(a,b));
           System.out.println((int)Math.floor(d));
           System.out.println(Math.ceil(d));
           System.out.println(Math.round(d));
           
       
    }
}