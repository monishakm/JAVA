import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    int n=s.nextInt();
	    System.out.println(Integer.toBinaryString(n));
	}
}
//decimal to binary:
s.o.p(Integer.toBinaryString(input));
//Binary to decimal:
 String n=s.next();
S.o.p(Integer.parseInt(n,2));
//deimal to octal:
S.o.p(Integer.toOctalString(n));
//octal to decimal:
  String n=s.next();
S.o.p(Integer.parseInt(n,8));
//decimal to hexadecimal:
S.o.p(Integer.toHexString(n));
//hexadecimal to decimal: 
String n=s.next();
S.o.p(Integer.parseInt(n,16));

