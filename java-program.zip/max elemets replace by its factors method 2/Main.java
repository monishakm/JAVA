import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    int n=s.nextInt();
	     int m=s.nextInt();
	     int a[][]=new int[n][m];
	     int m1=0;
	     for(int i=0;i<n;i++)
	     {
	         for(int j=0;j<m;j++)
	         {
	         a[i][j]=s.nextInt();
	         m1=Math.max(m1,a[i][j]);
	         }
	     }
	     for(int i=0;i<n;i++)
	     {
	         for(int j=0;j<m;j++)
	         {
	         if(m1%a[i][j]==0)
	         a[i][j]=m1;
	         }
	     }
	      for(int i=0;i<n;i++)
	     {
	         for(int j=0;j<m;j++)
	        System.out.print(a[i][j]+" ");
	        System.out.println();
	     }
		
	}
}
