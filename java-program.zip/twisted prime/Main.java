import java.util.*;
public class Main
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        int count=0,rev=0,count1=0;
        for(int i=1;i<=num;i++)
        {
            if(num%i==0)
            { 
                count+=1;
            }
        }
        while(num!=0)
        {
            rev=rev*10+num%10;
            num/=10;
        }
        for(int j=1;j<=rev;j++)
        {
            if(rev%j==0)
            {
                count1+=1;
            }
        }
        if(count==2 && count1==2)
        {
            System.out.println("Twisted Prime Number");
        }
        else
        {
            System.out.println("Not Twisted Prime Number");
        }

    }
}