import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
	    Scanner sc=new Scanner(System.in);
	    String a=sc.nextLine();
	    int n=a.length();
	    char b[]=a.toCharArray();
	    for(int i=0;i<n;i+=2)
	    {
	        int k=b[i+1]-'0';
	        while(k--!=0)
	        System.out.print(b[i]);
	    }
	}
	
}
