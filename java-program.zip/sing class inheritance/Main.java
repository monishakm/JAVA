class subject
{
    void name()
    {
        System.out.println("Maths");
    }
}
public class Main extends subject
{
    public static void main(String args[])
    {
        Main fav=new Main();
        fav.name();
    }
}
