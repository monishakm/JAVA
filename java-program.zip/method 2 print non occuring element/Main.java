import java.util.*;
public class Main 
    {
       public static void main (String args[]) 
       {
           Scanner sc = new Scanner(System.in);
           int n=sc.nextInt();
           int k=sc.nextInt();
           int a=0,b=1;
           while(n!=0)
           {
               int r=n%10;
               if(r!=k)
               {
                   a=a+r*b;
                   b*=10;
               }
               n/=10;
               
           }
           
           System.out.println(a7);
             
           
           
       }
    }
