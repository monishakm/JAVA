class pradeep
{
    void nikithaa()
    {
        System.out.println("lovers");
    }
}
class mamakuttyy
{
    void nikithaa()
    {
        System.out.println("Ex lover");
    }
}
class Revii
{
    void nikithaa()
    {
        System.out.println("Besti");
    }
}
public class Main
{
	public static void main(String[] args) {
	    System.out.println("love today");
	    pradeep a=new pradeep();
	    mamakuttyy b=new mamakuttyy();
	    Revii c=new Revii();
	    a.nikithaa();
	     b.nikithaa();
	      c.nikithaa();
	}
}
