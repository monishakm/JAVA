import java.util.*;
public class Main  
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        String a=sc.next();
        int n=a.length();
        char b[]=a.toCharArray();
        char c[]=new char[n];
        for(int i=n-1,j=0;i>=0;i--,j++)
        {
            c[i]=b[j];
        }
        String s1=new String(c);
        System.out.println(a.equals(s1)?"yes":"no");
        
    }
}