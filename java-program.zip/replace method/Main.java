import java.util.*;
public class Main 
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        String s1=sc.nextLine();
        int n=sc.nextInt();
        int m =sc.nextInt();
        StringBuffer str=new StringBuffer(s1);
        str.replace(n,m,"kook");
        System.out.println(str);
        
        
    }
}